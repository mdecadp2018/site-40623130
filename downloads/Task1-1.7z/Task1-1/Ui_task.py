from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(501, 481)
        Dialog.setMinimumSize(QtCore.QSize(501, 481))
        Dialog.setMaximumSize(QtCore.QSize(501, 481))
        Dialog.setSizeGripEnabled(True)
        self.PBwork = QtWidgets.QPushButton(Dialog)
        self.PBwork.setGeometry(QtCore.QRect(290, 440, 111, 31))
        font = QtGui.QFont()
        font.setFamily("Agency FB")
        font.setPointSize(16)
        self.PBwork.setFont(font)
        self.PBwork.setObjectName("PBwork")
        self.PBsave = QtWidgets.QPushButton(Dialog)
        self.PBsave.setGeometry(QtCore.QRect(410, 440, 81, 31))
        font = QtGui.QFont()
        font.setFamily("Agency FB")
        font.setPointSize(16)
        font.setStrikeOut(True)
        self.PBsave.setFont(font)
        self.PBsave.setObjectName("PBsave")
        self.LB = QtWidgets.QLabel(Dialog)
        self.LB.setGeometry(QtCore.QRect(10, 440, 271, 31))
        font = QtGui.QFont()
        font.setFamily("Agency FB")
        font.setPointSize(16)
        self.LB.setFont(font)
        self.LB.setObjectName("LB")
        self.TB = QtWidgets.QTextBrowser(Dialog)
        self.TB.setGeometry(QtCore.QRect(10, 10, 481, 421))
        font = QtGui.QFont()
        font.setFamily("Agency FB")
        font.setPointSize(20)
        self.TB.setFont(font)
        self.TB.setObjectName("TB")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Team_divider"))
        self.PBwork.setText(_translate("Dialog", "Load - Work"))
        self.PBsave.setText(_translate("Dialog", " Save as"))
        self.LB.setWhatsThis(_translate("Dialog", "<html><head/><body><p><br/></p></body></html>"))
        self.LB.setText(_translate("Dialog", "Loading..."))
        self.TB.setHtml(_translate("Dialog", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'Agency FB\'; font-size:20pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:\'PMingLiU\';\">Loading...</span></p></body></html>"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())

